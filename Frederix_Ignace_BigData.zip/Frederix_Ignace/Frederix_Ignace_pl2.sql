CREATE OR REPLACE TRIGGER biur
BEFORE INSERT or UPDATE 
ON KLAS_PERSTUDENT_PEROLOD
FOR EACH ROW
BEGIN
IF INSERTING THEN
IF to_char(:NEW.acjaar, 'yyyy') < to_char(sysdate,'yyyy') THEN
RAISE_APPLICATION_ERROR(-20000,'u kunt zich niet inschrijven in een jaar in het verleden');
END IF;
END INSERTING THEN;
ELSE
IF sysdate > (to_date('01-09-'|| to_char(sysdate,'yyyy'),'dd-mm-yyyy') THEN
RAISE_APPLICATION_ERROR(-20000,'u kunt zich niet meer uitschrijven voor dit vak');
END IF;
END;


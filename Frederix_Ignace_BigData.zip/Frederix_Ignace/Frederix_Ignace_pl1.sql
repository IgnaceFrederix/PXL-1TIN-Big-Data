CREATE OR REPLACE PROCEDURE plan_1tin_zit2
	(p_jaar	IN	NUMBER(4,0))
AS
	v_jaar	NUMBER=0;
	v_dag	NUMBER=0;
	v_aantalExamens NUMBER=0;
	v_huidigeDag	dual.sysdate%type;
	v_startExamen	dual.sysdate%type;
	v_huidigeDatum	dual.sysdate%type;
	v_olodcode	OLODS.olodcode%TYPE;
	
	
BEGIN
v_jaar=p_jaar;
v_huidige datum =("17-8-"|| to_char(v_jaar),'dd-mm-yyyy');
v_aantalExamens=count(SELECT * FROM OLODS WHERE olodcode LIKE '41TIN');
IF to_char(v_startExamen 'fmday') = 'saterday' OR to_char(v_startExamen 'fmday') = 'sunday'  THEN
v_startExamen = ((next_day(v_startExamen,'mon')||"-8-"v_jaar,'dd-mm-yyyy');
END IF
v_huidigeDatum = v_startExamen;
FOR i IN 1 .. v_aantalExamens LOOP
IF to_char(v_huidigeDatum 'fmday') = 'saterday' OR to_char(v_huidigeDatum 'fmday') = 'sunday'  THEN
v_huidigeDatum = ('(next_day(v_huidigeDatum,'mon')||"-8-"v_jaar,'dd-mm-yyyy');
END IF;
DBMS_OUTPUT.PUT_LINE("dit is dag " || i || "dat er een examen kan gepland worden op dag" || v_huidigeDatum);
END LOOP;
END;
/
	